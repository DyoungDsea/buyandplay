
<?php 
require 'session_track.php';
require 'function.php';
require 'clean.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Buy and Bet | Withdrawal Funds</title>
  <?php include 'style.php'; ?>


</head>
<body>

  <!-- preloader start -->
  <!-- <div id="preloader"></div> -->
  <!-- preloader end -->

  <div class="custom-cursor"></div>
  <!--  header-section start  -->
  
  <?php include 'header.php'; ?>
  <!--  header-section end  -->

  <!-- banner-section start -->
 
  <!-- banner-section end -->

  <!-- blog-details-section start -->
  <section class="blog-details-section mt-5">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-3" style="padding-left:50pxc;" >
          <div class="sidebar">
            <!-- widget end -->
            <div class="widget widget-categories">
              <!-- <h4 class="widget-title">Dashboard</h4> -->
              <?php include 'link.php' ?>
              

            </div>
            
          
          </div>
        </div>
        <!-- end of first col  -->

        <div class="col-lg-9 mt-3" >
        
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div class="card text-center">
                        <div class="card-header  my-3 text-success">
                         <p><b> Avaliable Balance </b></p>
                         <p style="color:red"><b>&#8358; <?php echo number_format($k['dwallet_balance'],2); ?> </b></p>
                        </div>
                        <div class="card-body">
                        <hr>
                        <p class="my-3">Make a withdrawal request</p>
                        <form class="cmn-form login-form mt-2" method="POST" action="withdrawal-process">
                            

                            <div class="row" style="margin-top:-16px">
                            <div class="col-md-6">
                            <div class="frm-group">
                            <input type="text" name="name" required  placeholder="Bank Account Name Here...">
                            </div>
                            </div>
                            <div class="col-md-6">
                            <div class="frm-group">
                            <input type="text" name="number" required  placeholder="Bank Account Number Here...">
                            </div>
                            </div>
                            </div>
                            
                            <div class="row" style="margin-top:-16px">
                            <div class="col-md-6">
                            <div class="frm-group">
                            <input type="text" name="bank" required  placeholder="Bank Name Here...">
                            </div>
                            </div>
                            <div class="col-md-6">
                            <div class="frm-group">
                            <input type="text" name="amount" user="<?php echo $_SESSION['userId'] ?>" id=check title="Only number is allow" required pattern="^[0-9]*$" placeholder="Amount Here...">
                            <p id="result" style="color:red"></p>
                            </div>
                            </div>
                            </div>

                            <div class="frm-group">
                            <input type="password" name="pass" required  placeholder="Enter Password Here...">
                            </div>

                            <div class="frm-group" id="button">
                            <button type="submit" name="load"  class="submit-btn">Proceed</button>
                            </div>
                        </form>
<a href="javascript:history.back()" style="margin: 20px 0" class="btn btn-info pull-right"> <i class="fa fa-arrow-circle-left"></i> Back</a>

                        </div>
                    </div>

                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
<!-- end of second col  -->




        
      </div>
    </div>
  </section>
  <!-- blog-details-section end -->
<div class="mb-4"></div>
  <!-- footer-section start -->
  <?php 
include('footer.php');
  ?>
  <!-- footer-section end -->

  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->
  <?php include('script.php'); ?>

</body>

</html>