
  <!-- footer-section start -->
  <footer class="footer-section">
    <div class="footer-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 col-sm-6">
            <div class="footer-widget widget-about">
              <a class="logo"> <img style="max-width:250px" src="assets/images/buybets.png" alt="site-logo"></a>
              <ul class="address-list">
                <!-- <li>79, Stadium Road, Rumuomasi, Port Harcourt, Nigeria</li> -->
                <li><?php echo $dweb_address; ?></li>
                <li> <?php echo $dweb_email; ?></li>
                <li><?php echo $dweb_phone; ?></li>
              </ul>
              <!-- <ul class="social-links d-flex">
                <li><a href="#0"><i class=" fa fa-facebook-f"></i></a></li>
                <li><a href="#0"><i class=" fa fa-twitter"></i></a></li>
                <li><a href="#0"><i class=" fa fa-youtube"></i></a></li>
                <li><a href="#0"><i class=" fa fa-dribbble"></i></a></li>
              </ul> -->
              <!-- <div class="play mt-3">
                <img style="width:25%" src="assets/images/play.png" alt="">
              </div> -->
            </div>
          </div>
          <div class="col-lg-2 col-sm-6">
            <div class="footer-widget widget-menu">
              <h3 class="widget-title">Menu</h3>
              <ul class="menu-links">
                <li><a href="index">Home</a></li>
                <li><a href="register">Signup</a></li>
                <li><a href="login">login</a></li>
                <!-- <li><a href="#">Promotions</a></li> -->
                <!-- <li><a href="#">Statisti</a></li> -->
              </ul>
            </div>
          </div>
          <div class="col-lg-2 col-sm-6">
            <div class="footer-widget widget-menu">
              <h3 class="widget-title">Menu</h3>
              <ul class="menu-links">
                <li><a href="about">About Us</a></li>
                <li><a href="blog">Blog</a></li>
                <!-- <li><a href="all-tips">All Tips</a></li> -->
                <li><a href="contact">Contact us</a></li>
              </ul>
            </div>

            
              <!-- <div class="play mt-3">
                <img style="width:25%" src="assets/images/play.png" alt="">
              </div> -->
          </div>
          <!-- <div class="col-lg-5 col-sm-6">
            <div class="footer-widget widget-subscribe">
              <h3 class="widget-title">subscribe</h3>
              <div class="widget-subscribe-body">
                <p>Subscribe to our newsletter for updates</p>
                <form class="subscribe-form" method="POST" action="newsletter">
                  <input type="email" name="email" required id="subs-emails" class="subs-email" placeholder="Email Address">
                  <input type="submit" value="Subscribe" class="sub-btn">
                </form>
              </div>
            </div>
          </div> -->
          <div class="col-lg-2 col-sm-6">
            <div class="footer-widget widget-menu plays">
                <div class="play mt-3">
                  <img style="width:100%" src="assets/images/play.png" alt="">
                </div>
                <div class="play mt-2">
                  <img style="width:100%" src="assets/part/group.png" alt="">
                </div>
                <div class="play mt-2">
                  <img style="width:100%" src="assets/part/first22.jpg" alt="">
                </div>
                <div class="play mt-2">
                  <img style="width:100%" src="assets/part/pay22.jpeg" alt="">
                </div>
            </div>

            
              <!-- <div class="play mt-3">
                <img style="width:25%" src="assets/images/play.png" alt="">
              </div> -->
          </div>

        </div>
      </div>
    </div><!-- footer-top end -->


    <div class="footer-bottom text-center">
      <div class="container">
        <p><?php echo date('Y'); ?> &copy; All Rights Reserved : Buy and Bet</p>
      </div>
    </div>
  </footer>
  <!-- footer-section end -->

  <!-- scroll-to-top start -->
  <div class="scroll-to-top">
    <span class="scroll-icon">
      <i class="fa fa-angle-up"></i>
    </span>
  </div>
  <!-- scroll-to-top end -->