
  <link rel="shortcut icon" type="image/png" href="assets/images/favicon.jpg"/>
  <!-- fontawesome css link -->
  <link rel="stylesheet" href="assets/css/fontawesome.min.css">
  <!-- flat icon css link -->
  <link rel="stylesheet" href="assets/css/flaticon.css">
  <!-- bootstrap css link -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <!-- animate css link -->
  <link rel="stylesheet" href="assets/css/animate.css">
  <!-- slick slider css link -->
  <link rel="stylesheet" href="assets/css/slick.css">
  <!-- lightcase css link -->
  <link rel="stylesheet" href="assets/css/lightcase.css">
  <!-- main style css link -->
  <link rel="stylesheet" href="assets/css/style.css">
  <!-- responsive css file -->
  <link rel="stylesheet" href="assets/css/responsive.css">