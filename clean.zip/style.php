<link rel="shortcut icon" type="image/png" href="assets/images/icon-.jpg"/>
  <!-- fontawesome css link -->
  <link rel="stylesheet" href="assets/css/fontawesome.min.css">
  <!-- flat icon css link -->
  <link rel="stylesheet" href="assets/css/flaticon.css">
  <!-- bootstrap css link -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <!-- animate css link -->
  <link rel="stylesheet" href="assets/css/animate.css">
  <!-- slick slider css link -->
  <link rel="stylesheet" href="assets/css/slick.css">
  <!-- lightcase css link -->
  <link rel="stylesheet" href="assets/css/lightcase.css">
  <link rel="stylesheet" href="assets/css/sweetalert.css">
  <link rel="stylesheet" href="_timepicker.min.css">
  <link rel="stylesheet" href="jquery-ui.css">
  <!-- main style css link -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/buy.css">
  <link rel="stylesheet" href="shared/toastr.min.css">
  <!-- responsive css file -->
  <link rel="stylesheet" href="assets/css/responsive.css">

  <!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" /> -->
  <style>
  .wallet{
    color:white;
    margin-top:30px;
  }

  .active-section{
    background:#ff3952; !important;
  }

  .nav-sided, .nav-sided li{
    display:block !important;
    width:100% !important;
  }

  .hover:hover .card{
    background:#000040; !important;
    color:white;
    
  }

  .prag p{
    margin-bottom:10px;
    border-bottom:1px solid #000040;
    padding-bottom:10px;
  }

  .mouse{
    font-size:20px;
  }

  @media only screen and (max-width: 768px){
    .hide-small{
      display:none;
  }

  .play img {
    max-width:20%
  }
}
/* .play{
    width:25%;
    margin-left:10px

} */

.inpy {
  display:flex;
  /* background:blue !important; */
}

.inpy input{
  width:50px !important;
  box-shadow:none;
  margin-top:5px
}


/* .buy {
  top:-40px !important;
} */

  </style>