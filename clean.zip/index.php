<?php
include("home.php");
$_SESSION['notification_session']="on";
?>